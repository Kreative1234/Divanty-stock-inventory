<?php

// src/Command/CreateUserCommand.php
namespace App\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Encoder\CsvEncoder;
use App\Entity\StockItem;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\Console\Helper\Table;


class UpdateStockCommand extends Command
{

    protected static $defaultName= 'divante:supplier-sync';
    // the name of the command (the part after "bin/console")
    public function __construct($projectDir, EntityManagerInterface $entityManager)
    {

        $this->projectDir = $projectDir;
        $this->entityManager=$entityManager;
        parent::__construct();
    }

    protected function configure()
    {
        $this->setDescription('update stock record')
        ->addArgument('markup', InputArgument::OPTIONAL, 'percentage markup', '20')
        ->addArgument('process_date', InputArgument::OPTIONAL, 'date of process', date_create()->format('y-m-d'));
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $processDate = $input->getArgument('process_date');
        $markup=($input->getArgument('markup')/100)+1;
        $supplierProducts = $this->getCsvRowsAsArray($processDate);
        $stockItemRepo=$this->entityManager->getRepository(StockItem::class);
        $existingCount=0;
        $newCount=0;
        $displayRowCount=0;

        $table = new Table($output);
        $displayTableData=array();

        foreach ($supplierProducts as $supplierProduct) {

            /** check if product is already exist **/ 

            if($existingStockItem= $stockItemRepo->findOneBy(['itemNumber'=>$supplierProduct['item_number']]))
            {
                $displayTableData[]=[$supplierProduct['item_number'],$supplierProduct['item_name'],$supplierProduct['description'],$supplierProduct['cost'].' zl'];
                $this->updateStockItem($existingStockItem,$supplierProduct, $markup);
                $existingCount++;
                continue;
        
                // dd($existingStockItem);
            }

            /** if product not exist it enter in database **/
            $this->createNewStockItem($supplierProduct, $markup);

            /** store data in table row **/
            $displayTableData[]=[$supplierProduct['item_number'],$supplierProduct['item_name'],$supplierProduct['description'],$supplierProduct['cost'].' zl'];
            $newCount++;
        }

        /** display table **/

        $table
            ->setHeaders(['product id', 'product name','product description','price'])
            ->setRows($displayTableData);
        $table->render();

        $this->entityManager->flush();
        $io= new symfonyStyle($input,$output);
        $io->success("$existingCount exisitng record has been updated and $newCount  has been added");
        return Command::SUCCESS;

      
    }


    /** insert data in database function **/
    public function createNewStockItem($supplierProduct, $markup)
    {

        $newStockItem=new StockItem();
        $newStockItem->setItemNumber($supplierProduct['item_number']);
        $newStockItem->setItemName($supplierProduct['item_name']);
        $newStockItem->setItemDescription($supplierProduct['description']);
        $newStockItem->setSupplierCost($supplierProduct['cost']);
        $newStockItem->setPrice($supplierProduct['cost']*$markup);
        $this->entityManager->persist($newStockItem);
    }


    /** update existing data in database  function **/
    
    public function updateStockItem($existingStockItem,$supplierProduct, $markup)
    {
        $existingStockItem->setSupplierCost($supplierProduct['cost']);
        $existingStockItem->setPrice($supplierProduct['cost']*$markup);
        $existingStockItem->setItemName($supplierProduct['item_name']);
        $existingStockItem->setItemDescription($supplierProduct['description']);
        $this->entityManager->persist($existingStockItem);

    }

    public function getCsvRowsAsArray($processDate)
    {
        $inputFile = $this->projectDir.'/public/supplier-inventory-files/book1.csv';
        $decoder = new Serializer([new ObjectNormalizer()], [new CsvEncoder()]);
        return $decoder->decode(file_get_contents($inputFile),'csv');
    }
}